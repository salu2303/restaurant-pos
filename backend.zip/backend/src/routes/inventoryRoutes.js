import express from "express";
import {
    getInventoryItems,
    addInventoryItem,
    updateInventoryItem,
    deleteInventoryItem
} from "../controllers/inventoryController.js";

import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", protect, authorize(["admin", "chef"]), getInventoryItems);
router.post("/", protect, authorize(["admin"]), addInventoryItem);
router.put("/:id", protect, authorize(["admin", "chef"]), updateInventoryItem);
router.delete("/:id", protect, authorize(["admin"]), deleteInventoryItem);

export default router;
