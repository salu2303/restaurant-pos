import express from "express";
import {
    getPayments,
    addPayment,
    getPaymentByOrder
} from "../controllers/paymentController.js";

import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", protect, authorize(["admin", "cashier"]), getPayments);
router.post("/", protect, authorize(["cashier"]), addPayment);
router.get("/:order_id", protect, authorize(["admin", "cashier"]), getPaymentByOrder);

export default router;
