import express from "express";
import {
    getOrders,
    createOrder,
    updateOrderStatus
} from "../controllers/orderController.js";

import { protect, authorize } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", protect, authorize(["admin", "cashier", "waiter"]), getOrders);
router.post("/", protect, authorize(["waiter"]), createOrder);
router.put("/:id", protect, authorize(["admin", "cashier", "waiter"]), updateOrderStatus);

export default router;
