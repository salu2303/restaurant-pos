import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pool from "../config/db.js";
import dotenv from "dotenv";

dotenv.config();

export const registerUser = async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        // ✅ Validate required fields
        if (!name || !email || !password || !role) {
            return res.status(400).json({ message: "All fields are required." });
        }

        // ✅ Check if the user already exists
        const [existingUsers] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
        if (existingUsers.length > 0) {
            return res.status(400).json({ message: "User already exists." });
        }

        // ✅ Hash the password
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // ✅ Insert new user into database
        const [result] = await pool.query(
            "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
            [name, email, hashedPassword, role]
        );

        res.status(201).json({ message: "User registered successfully" });

    } catch (error) {
        console.error("🔥 Error in registerUser:", error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

export const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // ✅ Check if user exists
        const [users] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
        if (users.length === 0) {
            return res.status(404).json({ message: "User not found" });
        }

        const user = users[0];

        // ✅ Check if password is correct
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: "Invalid credentials" });
        }

        // ✅ Debug: Ensure secret key is loaded
        if (!process.env.JWT_SECRET) {
            console.error("⚠️ JWT_SECRET is missing in .env file!");
            return res.status(500).json({ message: "Internal Server Error: JWT Secret Missing" });
        }

        // ✅ Generate JWT token correctly
        const token = jwt.sign(
            { id: user.id, name: user.name, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
        );

        console.log("✅ Generated Token:", token); // ✅ Debugging line

        res.json({ token, user: { id: user.id, name: user.name, role: user.role } });

    } catch (error) {
        console.error("🔥 Error in loginUser:", error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
};